var serverlessSDK = require('./serverless_sdk/index.js')
serverlessSDK = new serverlessSDK({
tenantId: 'tmaximini',
applicationName: 'apollo-lambda-app',
appUid: 'gXWkCgff5hYX1fLpN1',
tenantUid: 'XStvJD8TQl1FcT7z4x',
deploymentUid: 'a89e1ed3-c191-40b6-bda3-5d7cfb74a6de',
serviceName: 'apollo-lambda',
stageName: 'dev',
pluginVersion: '3.2.5'})
const handlerWrapperArgs = { functionName: 'apollo-lambda-dev-graphql', timeout: 6}
try {
  const userHandler = require('./index.js')
  module.exports.handler = serverlessSDK.handler(userHandler.graphqlHandler, handlerWrapperArgs)
} catch (error) {
  module.exports.handler = serverlessSDK.handler(() => { throw error }, handlerWrapperArgs)
}
